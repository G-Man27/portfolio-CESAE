package Enums;

public enum HeroisPermitidos {
    CAVALEIRO,ARQUEIRO,FEITICEIRO;
}
